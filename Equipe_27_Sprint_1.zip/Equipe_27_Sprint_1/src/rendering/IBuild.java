package rendering;

public interface IBuild {
    void build();
}
